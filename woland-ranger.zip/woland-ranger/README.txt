Add the contents of font folder to your fonts directory.
usually /usr/share/fonts or ~/.local/share/fonts 
then run fc-cache to update font list.
set your terminal font to be hack nerd font of your choosing 
or use any other nerd font that you like.

Credit:
ArianaAsl aka woland

Enjoy!